queuemanager = None
localfiles = None