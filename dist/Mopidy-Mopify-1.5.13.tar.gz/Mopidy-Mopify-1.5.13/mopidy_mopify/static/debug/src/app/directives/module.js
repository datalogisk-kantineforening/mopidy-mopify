'use strict';
var widgetModule = angular.module('mopify.widgets', [
    'spotify',
    'mopify.services.mopidy'
  ]);